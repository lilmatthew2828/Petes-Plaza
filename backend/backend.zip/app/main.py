from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import admin
from app.routes.wishlist import router as wishlist_router  #Matthew Kilpatrick
from app.routes.listings import router as listings_router #emmanuella obidike
from app.routes import listings, admin, purchaseHistory
from app.routes import seller


from app.config import settings
from app.database import engine
from app.database import Base
from app.routes.announcements import router as announcements_router
from app.auth import router as auth_router
from app.routes.uploads import router as uploads_router #Emmanuella Obidike
from app.routes import offers

 

# Create tables on startup
Base.metadata.create_all(bind=engine)

# Create FastAPI app
app = FastAPI(
    title="Petes Plaza",
    version="0.1.0",
    debug=settings.debug,
)

# Add CORS middleware
# Will change in production to only allow the frontend origin
# allow the origin that your Vite server is running on
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router)
app.include_router(admin.router)
app.include_router(listings.router)
app.include_router(announcements_router)
app.include_router(wishlist_router)
app.include_router(purchaseHistory.router)
app.include_router(uploads_router) #Emmanuella Obidike
app.include_router(seller.router) # new - mkp
app.include_router(offers.router)

@app.get("/")
def root():
    return {"message": "Petes Plaza API"}


@app.get("/health")
def health_check():
    return {"status": "ok"}
